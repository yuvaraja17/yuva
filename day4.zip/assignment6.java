import java.util.Scanner;
import java.io.*;
class avengers{
        String name,power,weapon,planet;
        int age;
        avengers (String name1,int age1,String power1,String weapon1,String planet1) {
           name = name1;
           age = age1;
           power = power1;
           weapon = weapon1;
           planet = planet1;
        }
        void displayDetails () {
            System.out.println("Avenger Name:" + name);
            System.out.println("Avenger Age:" + age);
            System.out.println("Avenger Power:" + power);
            System.out.println("Avenger Weapon:" + weapon);
            System.out.println("Avenger Planet:" + planet);
            System.out.println("___________________________");
        }
}

public class assignment6 extends IOException {
    public static void main(String arg[]) {
        avengers[] av =new avengers[5];

            av[0] = new avengers("iron man", 45, "machine", "suit", "earth");
        av[1] = new avengers("spider man", 19, "thinking", "web", "earth");
        av[2] = new avengers("Thor", 35, "thunder", "hammer", "no earth");
        av[3] = new avengers("hulk", 55, "angery", "hulk", "earth");
        av[4] = new avengers("captian", 105, "leader", "body", "earth");
        av[0].displayDetails();
        av[1].displayDetails();
        av[2].displayDetails();
        av[3].displayDetails();
        av[4].displayDetails();
    }
}
