package quiz;

public class game {

    question[] questions=new question[3];
    playername player=new playername();

    String[] questiondata={"What is the size of an boolean variable?","what is the default value of double variable?","which is faster,StringBuilder or StringBuffer."};
    String[] op1={"8 bit","0.0d","StringBuilder"};
    String[] op2={"16 bit","0.0f","StringBuffer"};
    String[] op3={"32 bit","0","Both"};
    String[] op4={"not precisely defined","not defined","None"};
    int[] ans={2,1,1};
    public void initGame()
    {
        for(int i=0;i<3;i++){
            questions[i]=new question();
        }
        for(int i=0;i<3;i++)
        {
            questions[i].qn=questiondata[i];
            questions[i].op1=op1[i];
            questions[i].op2=op2[i];
            questions[i].op3=op3[i];
            questions[i].op4=op4[i];
            questions[i].correctAns=ans[i];
        }
    }
    public void play()
    {
        player.getDetails();
        for(int i=0;i<3;i++)
        {
            boolean status=questions[i].askquestion();
            if(status==true)
            {
                System.out.println("-------------------------");
                System.out.println("Good Game!\t"+player.name);
                System.out.println("-------------------------");
                player.score=player.score+5;
            }
            else{
                System.out.println("-------------------------");
                System.out.println("oops,its wrong");
                System.out.println("-------------------------");
                player.score=player.score-5;
            }
        }
        System.out.println(player.name+",Your score is '"+player.score+"'");

    }

}
