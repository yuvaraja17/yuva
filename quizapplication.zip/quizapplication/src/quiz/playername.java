package quiz;
import java.util.Scanner;
public class playername {
    Scanner sc=new Scanner(System.in);
    public String name;
    int score=0;

    public void getDetails(){

        System.out.println("Enter Your Name:");
        name=sc.next();

    }

}
