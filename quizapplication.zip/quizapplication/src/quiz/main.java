package quiz;

public class main {

    public static void main(String[] args) {
        game game=new game();
        game.initGame();
        game.play();

    }
}
