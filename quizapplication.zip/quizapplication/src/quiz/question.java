package quiz;
import java.util.Scanner;

public class question {
    Scanner sc=new Scanner(System.in);
    String qn,op1,op2,op3,op4;
    int correctAns,userAns;

    public boolean askquestion()
    {
        System.out.println(qn);
        System.out.println("1. "+op1);
        System.out.println("2. "+op2);
        System.out.println("3. "+op3);
        System.out.println("4. "+op4);
        System.out.println("Please choose an option");
        userAns=sc.nextInt();
        if(userAns==correctAns){
            return true;
        }
        return false;
    }

}
