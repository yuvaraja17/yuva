import java.io.*;
import java.util.Scanner;
public class assignment4
{
public static void main(String arg[])
{
    int[] number = new int[5];
    int sum=0;
    for(int n=0;n<=4;n++)
    {
            System.out.println("Enter element stored at array index\t"+n);
            Scanner sc = new Scanner(System.in);
            number[n] = sc.nextInt();
            sum=sum+number[n];
    }
    System.out.println("The sum of entered array is here!\t"+sum);
}
}